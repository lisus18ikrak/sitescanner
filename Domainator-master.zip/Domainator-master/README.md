# Domainator

**A python3 based utility for information gathering and reconnaissance**

### Tested on

- Arch Linux
- Windows 10

### Download

You can download the latest version by cloning the GitHub repository:

	git clone https://github.com/WhiteOnBlackCode/Domainator

Alternatively download a ZIP file containing the repository.

### Install requirements

	pip install -r requirements.txt

### Usage

	python3 main.py
